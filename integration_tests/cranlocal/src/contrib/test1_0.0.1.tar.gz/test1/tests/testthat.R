library(testthat)
library(test1)

test_check("test1")
