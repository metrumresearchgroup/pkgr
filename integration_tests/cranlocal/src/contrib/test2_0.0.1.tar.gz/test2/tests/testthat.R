library(testthat)
library(test2)

test_check("test2")
