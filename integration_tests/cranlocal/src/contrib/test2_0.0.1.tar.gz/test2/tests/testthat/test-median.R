context("test-median.R")

test_that("can add two numbers", {
  expect_equal(add_two_numbers(2, 3), 5)
})
