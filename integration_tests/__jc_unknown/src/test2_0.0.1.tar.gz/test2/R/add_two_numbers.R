#' add two numbers
#' @param x first number
#' @param y second number
#' @export
add_two_numbers <- function(x,y) {
  return(x + y)
}
