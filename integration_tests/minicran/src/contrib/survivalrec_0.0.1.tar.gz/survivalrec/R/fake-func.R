#' fake function calling something in survival
#' @param .x fake param
#' @export
fake_func <- function(.x) {
  survival::is.Surv(.x)
}
