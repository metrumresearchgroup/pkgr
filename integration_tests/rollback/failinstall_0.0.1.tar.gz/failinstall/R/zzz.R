.onLoad <- function(libname, pkgname) {
 stop("this is a purposeful fail in .onLoad to simulate a package failing to install!", call. = FALSE)
}
