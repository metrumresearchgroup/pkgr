#' calculate a median
#' @param ... dots to pass to median
#' @export
my_median <- function(...) {
  stats::median(...)
}

stop("oh no failed")
