library(testthat)
library(testerror)

test_check("testerror")
