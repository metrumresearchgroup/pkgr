#' calculate a median
#' @param ... dots to pass to my_median
#' @export
my_super_median <- function(...) {
  test1::my_median(...)
}
